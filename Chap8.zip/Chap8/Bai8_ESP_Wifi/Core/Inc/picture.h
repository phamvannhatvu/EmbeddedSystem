/*
 * picture.h
 *
 *  Created on: Sep 26, 2023
 *      Author: HaHuyen
 */

#ifndef INC_PICTURE_H_
#define INC_PICTURE_H_

extern const unsigned char gImage_c_flag[37620];
extern const unsigned char gImage_l_flag[10440];

#endif /* INC_PICTURE_H_ */
